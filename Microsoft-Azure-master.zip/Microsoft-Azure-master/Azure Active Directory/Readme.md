﻿# Microsoft Azure Active Directory(AD)
