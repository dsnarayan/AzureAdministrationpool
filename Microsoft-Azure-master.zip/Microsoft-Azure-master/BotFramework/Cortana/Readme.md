﻿# Microsoft Azure Bot Framework : Cortana Channel

 The Microsoft Azure Bot Framework SDK allows you to build Azure applications that take advantage of scalable cloud computing resources.
