﻿# Microsoft Azure

The Microsoft Azure SDK allows you to build Azure applications that take advantage of scalable cloud computing resources.

## Microsoft Azure Stack

![alt text](https://github.com/psrsekhar/Microsoft-Azure/blob/master/azure-stack-services.png)

## Microsoft Azure Services

![alt text](https://github.com/psrsekhar/Microsoft-Azure/blob/master/Microsoft-Azure-Services.png)
